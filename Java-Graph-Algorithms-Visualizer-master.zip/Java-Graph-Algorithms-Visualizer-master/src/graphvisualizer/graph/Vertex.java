package graphvisualizer.graph;

public interface Vertex<V> {
    /* return element stored in vertex */
    V element();
}
